#include <iostream>
#include "rangerinterface.h"

RangerInterface::RangerInterface(){}