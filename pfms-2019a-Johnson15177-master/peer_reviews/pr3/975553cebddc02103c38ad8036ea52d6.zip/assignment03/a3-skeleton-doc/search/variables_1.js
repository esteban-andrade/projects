var searchData=
[
  ['bstation_5floc',['BSTATION_LOC',['../classSimulator.html#a4a32de8a20938532139a6746499d7285',1,'Simulator']]],
  ['bstation_5fref_5frate',['BSTATION_REF_RATE',['../classSimulator.html#a901e2a4bee11e07d7276857f95e88f50',1,'Simulator']]]
];
