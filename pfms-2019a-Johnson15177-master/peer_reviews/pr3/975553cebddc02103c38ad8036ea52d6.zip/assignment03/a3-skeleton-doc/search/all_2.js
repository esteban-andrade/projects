var searchData=
[
  ['controlfriendly',['controlFriendly',['../classSimulator.html#adb1cff57466c3b03fd738036cb9cee63',1,'Simulator']]]
];
