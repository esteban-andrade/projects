#include "rangerinterface.h"

RangerInterface::RangerInterface(){

}
