#include "ranger.h"

Ranger::Ranger()
{
}
