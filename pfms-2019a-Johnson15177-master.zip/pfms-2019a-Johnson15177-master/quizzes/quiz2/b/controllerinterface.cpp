#include "controllerinterface.h"

ControllerInterface::ControllerInterface()
{}
