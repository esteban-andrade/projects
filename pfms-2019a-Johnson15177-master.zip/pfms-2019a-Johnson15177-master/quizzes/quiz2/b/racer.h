#ifndef RACER_H
#define RACER_H

class Racer: public Car{
public
    Racer();

private:


};


#endif // RACER_H
