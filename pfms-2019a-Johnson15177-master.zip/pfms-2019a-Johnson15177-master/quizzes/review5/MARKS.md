Programming for Mechatronic Systems - Quiz 5
===================================

**[Marking Sheet - Quiz 5](https://forms.gle/hAZNvvvfNFiTQBG77)**

