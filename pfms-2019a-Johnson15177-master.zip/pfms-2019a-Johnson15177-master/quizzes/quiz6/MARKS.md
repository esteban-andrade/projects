Programming for Mechatronic Systems - Quiz 6
===================================

**[Marking Sheet - Quiz 6](https://forms.gle/9uzhH4XFEuJezkz56)**

