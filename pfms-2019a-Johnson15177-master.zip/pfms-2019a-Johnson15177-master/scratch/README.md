# pfms
This is your individual scratch folder, you can use it to backup your pre-work, work during class time and assignments, structure and organisation are completely at your leisure, suggested organisation below.

## Suggested Organisation
* assignments - Your attempts at assignments, containing sub-folders per assignment
* pre-work - pre-work, containing sub-folders per week of your pre-work (week01 - week12)
* tutorials - in class attempts, containing sub-folders per week of your tutorial work
